package com.example.caption.model;

public class CaptionResponse {
    private String caption;

    public CaptionResponse(String caption) {
        this.caption = caption;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }
}
