package com.example.caption.controller;

import com.example.caption.service.CaptionService;
import com.example.caption.model.CaptionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api")
public class ImageController {

    @Autowired
    private CaptionService captionService;

    @PostMapping("/caption")
    public ResponseEntity<CaptionResponse> getCaption(@RequestParam("image") MultipartFile file) throws IOException {
        String caption = captionService.generateCaption(file);
        return ResponseEntity.ok(new CaptionResponse(caption));
    }
}
