# 🖼️ Image Caption Generator (Java Spring Boot)

A simple web application to upload an image and generate an AI-powered caption using the HuggingFace API.

## 🛠️ Features
- Upload image via web form
- Generates caption using AI (ViT-GPT2)
- Spring Boot backend + Thymeleaf frontend

## 🚀 Run the App

```bash
mvn spring-boot:run
```

Visit: `http://localhost:8080`

## 🧠 Powered by
- [HuggingFace Inference API](https://huggingface.co/docs/api-inference/)
- `nlpconnect/vit-gpt2-image-captioning` model

## 🔑 Setup
Replace `YOUR_HUGGINGFACE_API_KEY` in `CaptionService.java` with your actual HuggingFace token.

## 📄 License
MIT
